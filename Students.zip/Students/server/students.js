const express = require('express');
const db = require('./db');
const utils = require('./utils');
const router = express.Router();

router.get('/students', (request, response) => {
    const statement = `select StudentId,Student_name,Student_Gender,student_Class,student_Email,student_Address,Contact_Number from student`;
    const connection = db.connect();
    connection.query(statement, (error, drink) => {
        connection.end();
        response.send(utils.createResponse(error, students));
    });
});

router.post('/students', (request, response) => {
    const {Student_name,Student_Gender,student_Class,student_Email,student_Address,Contact_Number} = request.body;
    const connection = db.connect();
    const statement = `insert into student
            (Student_name,Student_Gender,student_Class,student_Email,student_Address,Contact_Number) values 
            ('${Student_name}','${Student_Gender}','${student_Class}','${student_Email}','${student_Address}','${Contact_Number}')`;
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    })
});



module.exports = router;